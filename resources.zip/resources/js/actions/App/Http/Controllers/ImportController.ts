import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/'
*/
const index980bb49ee7ae63891f1d891d2fbcf1c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

index980bb49ee7ae63891f1d891d2fbcf1c9.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/'
*/
index980bb49ee7ae63891f1d891d2fbcf1c9.url = (options?: RouteQueryOptions) => {
    return index980bb49ee7ae63891f1d891d2fbcf1c9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/'
*/
index980bb49ee7ae63891f1d891d2fbcf1c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/'
*/
index980bb49ee7ae63891f1d891d2fbcf1c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/'
*/
const index980bb49ee7ae63891f1d891d2fbcf1c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/'
*/
index980bb49ee7ae63891f1d891d2fbcf1c9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/'
*/
index980bb49ee7ae63891f1d891d2fbcf1c9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index980bb49ee7ae63891f1d891d2fbcf1c9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index980bb49ee7ae63891f1d891d2fbcf1c9.form = index980bb49ee7ae63891f1d891d2fbcf1c9Form
/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/transactions'
*/
const indexe5aa2cad321b30063c3b415df5452200 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexe5aa2cad321b30063c3b415df5452200.url(options),
    method: 'get',
})

indexe5aa2cad321b30063c3b415df5452200.definition = {
    methods: ["get","head"],
    url: '/transactions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/transactions'
*/
indexe5aa2cad321b30063c3b415df5452200.url = (options?: RouteQueryOptions) => {
    return indexe5aa2cad321b30063c3b415df5452200.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/transactions'
*/
indexe5aa2cad321b30063c3b415df5452200.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexe5aa2cad321b30063c3b415df5452200.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/transactions'
*/
indexe5aa2cad321b30063c3b415df5452200.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexe5aa2cad321b30063c3b415df5452200.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/transactions'
*/
const indexe5aa2cad321b30063c3b415df5452200Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexe5aa2cad321b30063c3b415df5452200.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/transactions'
*/
indexe5aa2cad321b30063c3b415df5452200Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexe5aa2cad321b30063c3b415df5452200.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ImportController::index
* @see app/Http/Controllers/ImportController.php:12
* @route '/transactions'
*/
indexe5aa2cad321b30063c3b415df5452200Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: indexe5aa2cad321b30063c3b415df5452200.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

indexe5aa2cad321b30063c3b415df5452200.form = indexe5aa2cad321b30063c3b415df5452200Form

export const index = {
    '/': index980bb49ee7ae63891f1d891d2fbcf1c9,
    '/transactions': indexe5aa2cad321b30063c3b415df5452200,
}

/**
* @see \App\Http\Controllers\ImportController::importMethod
* @see app/Http/Controllers/ImportController.php:18
* @route '/import'
*/
export const importMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importMethod.url(options),
    method: 'post',
})

importMethod.definition = {
    methods: ["post"],
    url: '/import',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ImportController::importMethod
* @see app/Http/Controllers/ImportController.php:18
* @route '/import'
*/
importMethod.url = (options?: RouteQueryOptions) => {
    return importMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ImportController::importMethod
* @see app/Http/Controllers/ImportController.php:18
* @route '/import'
*/
importMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: importMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ImportController::importMethod
* @see app/Http/Controllers/ImportController.php:18
* @route '/import'
*/
const importMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: importMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ImportController::importMethod
* @see app/Http/Controllers/ImportController.php:18
* @route '/import'
*/
importMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: importMethod.url(options),
    method: 'post',
})

importMethod.form = importMethodForm

/**
* @see \App\Http\Controllers\ImportController::deleteAll
* @see app/Http/Controllers/ImportController.php:33
* @route '/delete-all'
*/
export const deleteAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deleteAll.url(options),
    method: 'post',
})

deleteAll.definition = {
    methods: ["post"],
    url: '/delete-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ImportController::deleteAll
* @see app/Http/Controllers/ImportController.php:33
* @route '/delete-all'
*/
deleteAll.url = (options?: RouteQueryOptions) => {
    return deleteAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ImportController::deleteAll
* @see app/Http/Controllers/ImportController.php:33
* @route '/delete-all'
*/
deleteAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deleteAll.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ImportController::deleteAll
* @see app/Http/Controllers/ImportController.php:33
* @route '/delete-all'
*/
const deleteAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deleteAll.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ImportController::deleteAll
* @see app/Http/Controllers/ImportController.php:33
* @route '/delete-all'
*/
deleteAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: deleteAll.url(options),
    method: 'post',
})

deleteAll.form = deleteAllForm

const ImportController = { index, importMethod, deleteAll, import: importMethod }

export default ImportController