import ImportController from './ImportController'
import Settings from './Settings'

const Controllers = {
    ImportController: Object.assign(ImportController, ImportController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers